public enum Suit {

    CLUB,
    DIAMOND,
    SPADE,
    HEART
}
